//This module carries out the following
// 1. Peer list generation
// 2. end to end communication b/w the peers but for the actual file sharing
//the actual file sharing is handled by the http server.
// there will be udp/raw tcp file sharing implemented in future versions for academic purposes

var dgram = require('dgram'),
	peersocket = dgram.createSocket('udp4'),	//UDP socket
	BROADCAST_ADDRESS = '255.255.255.255',		
	events = require('events'),
	udpEventEmitter = new events.EventEmitter(), //This is used to trigger/listen to events related to the UDP side of the code
	os = require('os'), //for getting the hostname of the system.
	myAddress,
	hostName = os.hostname(),
	platform = os.platform(),
	localIps = [], //to hold the current system's addresses.
	peers = [];

//Finding the local ip address of this computer in all of the interfaces
//This is done because, when a peer broadcasts over a network, it also receives it's message back.
//we need to know the address of the current system on the network to filter out it's own message. 
var findlocalIps = function(){

	var ifaces = os.networkInterfaces();
	//console.log(hostName);
	for (var dev in ifaces) {

	  	ifaces[dev].forEach(function(details){
    	
    		if (details.family=='IPv4') {
      		
      			localIps.push(details.address);
    		}
  		});
	}
}
//binding the UDP socket to our app's port. i think 9090 is a good number.
//when we do not specify the address after the port number, the server listens on all interfaces.
	peersocket.bind(9090,function(){

		console.log('UDP socket is alive');
		//When a machine runs our APP, it broadcasts it's presence to other machines in a wifi network ( could be any network )
		//We have to specifically enable Broadcast in node js for it to allow broadcasting
		peersocket.setBroadcast(true);	//the app broadcast's it's presence here.
		broadcast('hello' + '\0' + hostName + '\0' + platform); 
		myAddress = peersocket.address().address;
		console.log(myAddress);
		//console.log(iface);	
		findlocalIps();
		console.log('My local IP addresses are ' + localIps);
	});

	//I think if we encapsulate the broadcasting statements into a function, we could re use it,
	//in situations where we want to broadcast something

	var broadcast = function(msg){

		var buffer = new Buffer(msg);
		peersocket.send(buffer,0,buffer.length,9090,BROADCAST_ADDRESS,function(err,bytes){

			if(msg.split('\0')[0] === 'bye'){

				console.log('Saying Goodbye to other peers!');
				console.log(peers);
				process.exit(0);
			}else{

				console.log('A broadcast is made!');

			}

		});

	};

	var sendMessage = function(msg,rinfo){

		var buffer = new Buffer(msg);
		peersocket.send(buffer,0,buffer.length,9090,rinfo.address,function(err,bytes){


		});		

	}

	//recursive pushToPeers

	var pushToPeers = function(address,hostname,platform){

		var index;
		var flag = true;
		var peer_details = { 'address' : address, 'hostname' : hostname, 'platform' : platform };

		for(index=0; index < peers.length ; index++){

			if(address === peers[index].address){

				console.log('Address is already present!');
				flag=false;
			}

		}

		if(flag){

			peers.push(peer_details);
			udpEventEmitter.emit('joined',peer_details);
		}

	}

	//Removes a peer from the peer list
	var removePeer = function(address){

		var index;
		var peer_hostname;

		for(index = 0; index<peers.length; index++){

			if(peers[index].address === address){
				peer_hostname = peers[index].hostname;				
				peers.splice(index,1);
				console.log('removed');
				udpEventEmitter.emit('quit',peer_hostname);
				//return peer_hostname; // bug AS002 : need to write this function in a better way.
			}
		}
	};

	var processIncomingMessage = function(msg, rinfo){

		var message = msg.toString().split('\0');

		switch(message[0]){

			case 'hello' : //When a new peers comes alive, it sends a hello message
						   console.log('We\'ve received a hello message from ' + message[1] + ' with address ' + rinfo.address );
						   console.log('We\'ll reply to the hello message with an ack');
						   messageString = 'ack' + '\0' + hostName + '\0' + platform;
						   sendMessage(messageString,rinfo);
						   //and push the address of the client into peers list
						   pushToPeers(rinfo.address,message[1],message[2]);
						   // console.log('here\'s my peer list ' + peers);
						   console.log(peers);
						   break;
			case 'ack'	 : //when someone's already alive, they acknowledge our hello
						   console.log('We\'ve received an ack from ' + message[1] + ' with address ' + rinfo.address);
						   console.log('I\'ve added the peer to my peer list');
						   pushToPeers(rinfo.address,message[1],message[2]);
						   // console.log('here\'s my peer list ' + peers);
						   console.log(peers);
						   break;
			case 'bye'	 : //when someone's leaving the peers list
						   console.log('We\'ve received a bye from ' + message[1] + ' with address ' + rinfo.address);
						   //we have to remove that computer from the peer list
						   console.log('I\'m removing the peer from my peer list');
						   removePeer(rinfo.address);
						   console.log('The peer is removed!');
						   console.log('My peer list is now');
						   console.log(peers);
						   // console.log('here\'s my peer list ' + peers);
						   break;
			case  'file' : //when someone sends a file
						   //to do
						   break;
			case  'confirm' : //when someone asks for a confirmation of a file download!
							console.log('Confirmation asked for files '+ message[1]);
							//event emitted to the interface to be sent to the user via socket.io
							udpEventEmitter.emit('YES_OR_NO',message[1],rinfo);
							break;
			case 'choice'	: //when the receiver sends back his choice, we should let the user know about it.
							console.log('The receiver ' + message[2] +' has responded with ' + message[1]);
							udpEventEmitter.emit('peer_choice_has_arrived',{ 'address' : rinfo.address, 'hostname' : message[2], 'choice' : message[1], 'platform' : message[3] });
							break;
			default : console.log('This is either a message from the app itself or a junk message ' + message + ' ');

		};

	};

	//The application listens to datagrams from peers in the network
	//this datagram can be anything
	//it can be any status message, ie 'ack','quit' etc, broadcast message ie 'hello' or a file or it's parts

	peersocket.on('message',function(msg,rinfo){

		//the msg is a buffer, we need to convert it to string first
		if(localIps.some(function(localIp){

			return(localIp === rinfo.address);

		})){
			//console.log('Message from the host to itself!');
		}else{

			processIncomingMessage(msg,rinfo);
		}

	});

	//This piece of code handles the close event CLTRL + C
	//But this is only one of the possible scenarios where the app is closed.
	//a bye broadcast should be made when the browser if closed too.
	//when implementing with node-webkit as a desktop app, it will be imperative
	process.on('SIGINT',function(){

		broadcast('bye' + '\0' + hostName);
		console.log('Your App is now shutting down');		

	});

	//Natural exit of the process
	process.on('exit',function(){

		broadcast('bye' + '\0' + hostName);
		console.log('Exit code!');	

	});

	// process.on('SIGHUP', function(){

	// 	console.log('SIGHUP');

	// });

	// //uncaught exception error handler
	// process.on('uncaughtException', function(err) {
  
 //  		console.log('Caught exception: ' + err);
	// });

	//in a sender - receiver perspective, this is on the sender's part.
	//This code send the messages to selected peers asking them if they want the file or not.
	//note : receivers should be an array of objects
	udpEventEmitter.on('ask_peers_to_confirm',function(receivers,noOfFiles){

		var index;
		var messageString = 'confirm' + '\0' + noOfFiles;
		console.log(receivers.length);
		for(index = 0; index < receivers.length; index++){
			var that = index;
			sendMessage(messageString,receivers[index],function(){

				console.log(receivers[that]);

			});

		}

	});

	//in a sender - receiver perspective, this is on the receiver's part.
	//This code sends the peer's choice to the file sender.
	//when the receiver confirms whether he wants it or not it, we should let the sender know about it. 
	udpEventEmitter.on('peer_has_confirmed',function(choice,senderInfo){

		var messageString = 'choice' + '\0' + choice +'\0' + hostName + '\0' + platform;

		sendMessage(messageString,senderInfo,function(){

			console.log('The choice is sent back to the sender!');

		});

	});

	//we export the list of peers and the udp event emitter, which enables the tcp module to hook into and emit events related to the udp module.
	module.exports = {

		peers : peers,
		udpEventEmitter : udpEventEmitter

	};